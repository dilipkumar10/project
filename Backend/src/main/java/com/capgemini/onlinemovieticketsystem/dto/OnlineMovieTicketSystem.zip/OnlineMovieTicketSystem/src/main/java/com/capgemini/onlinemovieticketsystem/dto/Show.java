package com.capgemini.onlinemovieticketsystem.dto;

import java.sql.Time;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="shows")
public class Show {
	@Id
	@Column
	private int showId;
	@Column
	private Time showStartTime;
	@Column
	private Time showEndTime;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "seaters")
	private List<Seat> seats;
	@Column
	private String showName;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "movies")
	private Movie movieName;
	@Column
	private int theaterId;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "screenId")
	private Show shows;
}
