package com.capgemini.onlinemovieticketsystem.exception;

public class OnlineMovieTicketException extends RuntimeException {
	public OnlineMovieTicketException(String message) {
		super(message);
	}
}
