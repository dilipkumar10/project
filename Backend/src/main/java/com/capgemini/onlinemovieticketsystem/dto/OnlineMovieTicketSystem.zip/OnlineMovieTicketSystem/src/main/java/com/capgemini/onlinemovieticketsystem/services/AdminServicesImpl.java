package com.capgemini.onlinemovieticketsystem.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.onlinemovieticketsystem.dao.AdminDao;
import com.capgemini.onlinemovieticketsystem.dto.Movie;
import com.capgemini.onlinemovieticketsystem.dto.Screen;
import com.capgemini.onlinemovieticketsystem.dto.Show;
import com.capgemini.onlinemovieticketsystem.dto.Theater;

@Service
public class AdminServicesImpl implements AdminServices {
	@Autowired
	private AdminDao adminDao;

	@Override
	public Theater addTheater(Theater theater) {
		// TODO Auto-generated method stub
		return adminDao.addTheater(theater);
	}

	@Override
	public boolean deleteTheater(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Movie addMovie(Movie movie) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteMovie(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Screen addScreen(Screen screen) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteScreen(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Show addShow(Show show) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteShow(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
