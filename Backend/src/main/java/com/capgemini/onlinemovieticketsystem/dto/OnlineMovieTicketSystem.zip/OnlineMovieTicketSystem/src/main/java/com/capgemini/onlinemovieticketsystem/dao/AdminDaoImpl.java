package com.capgemini.onlinemovieticketsystem.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.transaction.Transaction;

import org.springframework.stereotype.Repository;

import com.capgemini.onlinemovieticketsystem.dto.Movie;
import com.capgemini.onlinemovieticketsystem.dto.Screen;
import com.capgemini.onlinemovieticketsystem.dto.Show;
import com.capgemini.onlinemovieticketsystem.dto.Theater;
import com.capgemini.onlinemovieticketsystem.exception.OnlineMovieTicketException;
@Repository
public class AdminDaoImpl implements AdminDao{
@PersistenceUnit
private EntityManagerFactory entityManagerFactory;
	@Override
	public Theater addTheater(Theater theater) {
		// TODO Auto-generated method stub
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		try {
			entityTransaction.begin();
			entityManager.persist(theater);
			entityTransaction.commit();
			entityManager.close();
			return theater;
		}catch(Exception e) {
			throw new OnlineMovieTicketException("Theater already exists");
		}
	}

	@Override
	public boolean deleteTheater(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Movie addMovie(Movie movie) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteMovie(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Screen addScreen(Screen screen) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteScreen(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Show addShow(Show show) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteShow(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
