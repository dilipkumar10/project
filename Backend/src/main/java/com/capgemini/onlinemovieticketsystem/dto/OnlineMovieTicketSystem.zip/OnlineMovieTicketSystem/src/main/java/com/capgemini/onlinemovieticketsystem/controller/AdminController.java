package com.capgemini.onlinemovieticketsystem.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.onlinemovieticketsystem.dto.Admin;
import com.capgemini.onlinemovieticketsystem.dto.OnlineMovieTicketResponse;
import com.capgemini.onlinemovieticketsystem.dto.Theater;
import com.capgemini.onlinemovieticketsystem.services.AdminServices;

@CrossOrigin
@RestController
public class AdminController {
	@Autowired
	private AdminServices adminServices;
	@PostMapping(path="/add-theater",produces=MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public OnlineMovieTicketResponse addTheater(@RequestBody Theater theater) {
		OnlineMovieTicketResponse onlineMovieTicketResponse=new OnlineMovieTicketResponse();
		if(adminServices.addTheater(theater)!=null) {
			onlineMovieTicketResponse.setStatusCode(200);
			onlineMovieTicketResponse.setMessage("Success");
			onlineMovieTicketResponse.setDescription("Theater added successfully");
			onlineMovieTicketResponse.setBeans(Arrays.asList(theater));
		}else {
			onlineMovieTicketResponse.setStatusCode(401);
			onlineMovieTicketResponse.setMessage("failure");
			onlineMovieTicketResponse.setDescription("Customer not added");
		}
		return onlineMovieTicketResponse;
	}
}
